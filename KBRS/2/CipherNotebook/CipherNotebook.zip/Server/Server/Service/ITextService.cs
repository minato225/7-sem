﻿namespace Server.Servers
{
    public interface ITextService
    {
        string GetText(string fileName);
    }
}
