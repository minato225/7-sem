import os
import sys

if __name__ == "__main__":
    stats = os.stat(sys.argv[0])
    print(stats.st_size.__str__() + "B")