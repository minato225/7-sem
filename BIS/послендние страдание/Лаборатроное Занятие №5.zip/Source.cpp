#include <iostream>

int main(int argc, char** argv) {
	std::cout << argv[0];
	std::cin.get();
}