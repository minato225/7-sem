﻿using System;
using System.Text;
using System.Windows;

namespace Desctop_ASCII
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Console.OutputEncoding = Encoding.GetEncoding("IBM437");
            var text = new StringBuilder();
            for (int i = 0; i < 256; i++)
            {
                text.Append($"{(char)i}_{i.ToString("X2")}");
                if ((i + 1) % 16 == 0)
                    text.Append("\n");
            }

            MainText.Text = text.ToString();
        }
    }
}
